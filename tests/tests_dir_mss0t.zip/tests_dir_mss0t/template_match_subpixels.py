"""
Function: template_match_subpixels
==================================

This function is designed to help you precisely track specific points
of interest (POIs) across a sequence of images. It's built on top of OpenCV's 'cv2.matchTemplate', but
it takes the accuracy a significant step further by estimating POI locations with *sub-pixel* precision.
This is achieved through a clever technique: parabolic fitting of the correlation map around the maximum
match point.

### What is it for? (Purpose)
This function is ideal for scientific and engineering applications where highly accurate displacement
tracking of small regions in image sequences is critical. Imagine you're analyzing microscopic movements,
tracking subtle deformations in materials, or monitoring precise shifts in an object's position –
'template_match_subpixels' is built for these scenarios. Each "template" you define consists of a
specific point of interest (the exact coordinate you want to track) and a bounding box region that
serves as the visual pattern to be matched.

### How is it different from 'cv2.matchTemplate'?
While 'cv2.matchTemplate' is a great starting point, 'template_match_subpixels' offers several key enhancements:
- **Sub-pixel Accuracy:** The most significant difference! Instead of just giving you integer pixel coordinates,
  this function refines the location to fractions of a pixel, providing much higher precision.
- **Multiple Template Support:** You're not limited to tracking just one thing. This function can handle
  multiple templates simultaneously, each with its own properties and even its own motion prediction.
- **Floating-Point Location Estimates:** It natively accepts and returns floating-point coordinates for POIs,
  which is essential for working with sub-pixel data.
- **Matching Quality Coefficient:** For every template, you'll receive a quantitative measure of how well it
  was matched in the current image. This "coefficient" helps you assess the reliability of each track.
- **Adaptive Search Range:** You can define a search area based on your expected displacement, which can
  make the tracking more efficient and robust, especially for larger movements.

### Input Parameters:
Let's break down what you need to provide to the function:

- 'init_img':
    - Type: Grayscale OpenCV image (NumPy array).
    - What it is: This is your "reference" or "initial" image. It's where you'll define the original
      locations of the points and templates you want to track.

- 'curr_img':
    - Type: Grayscale OpenCV image (NumPy array).
    - What it is: This is your "current" image, where the function will search for the templates
      defined from 'init_img'.

- 'init_templates':
    - Type: 'np x 6' NumPy array of 'float32'.
    - What it is: This is the core definition of your templates. Each row in this array represents
      one template and contains 6 crucial values: '[xi, yi, x0, y0, w, h]'.
        - '(xi, yi)': These are the *sub-pixel coordinates* of your Point of Interest (POI)
          within the 'init_img'. This is the exact point you want to track.
        - '(x0, y0)': These are the integer top-left corner (x, y) coordinates of the *bounding box*
          that defines the template region in 'init_img'. This region is the visual pattern that
          'cv2.matchTemplate' will use for matching.
        - '(w, h)': These are the integer width and height of the bounding box (template region).

- 'curr_templates' (Optional):
    - Type: 'np x 2' NumPy array of 'float32', or 'None'.
    - What it is: This parameter allows you to provide an *initial guess* for the POI locations
      '[xi, yi]' in the 'curr_img'.
    - Default: If you leave this as 'None' (which is often fine), the function will assume that
      your initial guess for the current POI locations is simply the '(xi, yi)' from 'init_templates'.
      This is a good starting point if you expect small movements.

- 'search_range_factors' (Optional):
    - Type: Scalar (float) or a NumPy array/list of floats.
    - What it is: This controls how large the search area will be in 'curr_img' around your
      initial guess.
    - If you provide a single 'scalar' value (e.g., '2.0'), this factor will be applied to the
      search area for *all* templates. A higher value means a larger search area, which is useful
      if you expect larger displacements between 'init_img' and 'curr_img'.
    - If you provide a 'list' or 'array' of factors (its length must match the number of templates),
      you can apply different search range factors to each individual template. This offers fine-grained
      control.
    - Default: '1.0' (meaning the search range is based on the initial guess and template size).

### Output Values:
The function will return two important pieces of information:

- 'updated_templates':
    - Type: 'np x 2' NumPy array of 'float32'.
    - What it contains: Each row '[xi_new, yi_new]' represents the *refined, sub-pixel accurate*
      location of the tracked POI in the 'curr_img'. This is your main result – the new position of your point!

- 'coeffs':
    - Type: 'np' sized NumPy array of 'float32'.
    - What it contains: Each value in this array is the *matching quality coefficient* for the
      corresponding template. A value closer to 1 indicates a very strong and confident match,
      while values closer to 0 or negative suggest a poor or no match. This helps you understand
      how well each point was tracked.

### Example Usage:
Let's see 'template_match_subpixels' in action with a few common scenarios.

'''python
import numpy as np
import cv2

# --- Create some dummy images for demonstration ---
# img1: A 300x300 white image with two black squares
img1 = np.ones((300, 300), dtype=np.uint8) * 255
cv2.rectangle(img1, (140, 140), (150, 150), (0, 0, 0), -1) # First square
cv2.rectangle(img1, (150, 150), (160, 160), (0, 0, 0), -1) # Second square

# img2: Same as img1, but squares are shifted slightly (e.g., by 1 pixel right, 2 pixels down)
img2 = np.ones((300, 300), dtype=np.uint8) * 255
cv2.rectangle(img2, (141, 142), (151, 152), (0, 0, 0), -1)
cv2.rectangle(img2, (151, 152), (161, 162), (0, 0, 0), -1)

# --- Case 1: Track a single template with default initial guess ---
print("--- Case 1: Tracking a single template ---")
# Define one template:
# POI at (150.0, 150.0)
# Template bounding box: top-left at (135, 135), width 30, height 30
init_templates_single = np.array([[150.0, 150.0, 135, 135, 30, 30]], dtype=np.float32)
new_positions_single, coeffs_single = template_match_subpixels(img1, img2, init_templates_single)
print("Updated POI (single):", new_positions_single)
print("Matching Coefficient (single):", coeffs_single)
print("-" * 40)

# --- Case 2: Track multiple templates ---
print("--- Case 2: Tracking multiple templates ---")
# Define two templates:
# Template 1: POI (150.0, 150.0), box (135, 135, 30, 30)
# Template 2: POI (160.0, 160.0), box (150, 150, 20, 20)
init_templates_multi = np.array([
    [150.0, 150.0, 135, 135, 30, 30],
    [160.0, 160.0, 150, 150, 20, 20]
], dtype=np.float32)
new_positions_multi, coeffs_multi = template_match_subpixels(img1, img2, init_templates_multi)
print("Updated POIs (multiple):", new_positions_multi)
print("Matching Coefficients (multiple):", coeffs_multi)
print("-" * 40)

# --- Case 3: Use a custom initial guess for the current POI location ---
print("--- Case 3: Using a custom initial guess ---")
# Let's say we expect the first point to have moved to (151.5, 152.5)
custom_curr_guess = np.array([[151.5, 152.5]], dtype=np.float32)
new_positions_custom_guess, coeffs_custom_guess = template_match_subpixels(
    img1, img2, init_templates_single, curr_templates=custom_curr_guess
)
print("Updated POI (custom guess):", new_positions_custom_guess)
print("Matching Coefficient (custom guess):", coeffs_custom_guess)
print("-" * 40)

# --- Case 4: Customize the search factor ---
print("--- Case 4: Customizing search factor ---")
# Increase search range by a factor of 2.0 for all templates
new_positions_large_search, coeffs_large_search = template_match_subpixels(
    img1, img2, init_templates_single, search_range_factors=2.0
)
print("Updated POI (large search):", new_positions_large_search)
print("Matching Coefficient (large search):", coeffs_large_search)
print("-" * 40)

# --- Case 5: Customize search factors for multiple templates individually ---
print("--- Case 5: Customizing search factors individually ---")
# Template 1: search factor 2.0, Template 2: search factor 1.5
individual_search_factors = np.array([2.0, 1.5], dtype=np.float32)
new_positions_individual_search, coeffs_individual_search = template_match_subpixels(
    img1, img2, init_templates_multi, search_range_factors=individual_search_factors
)
print("Updated POIs (individual search):", new_positions_individual_search)
print("Matching Coefficients (individual search):", coeffs_individual_search)
print("-" * 40)

# For visualization, you might want to draw the tracked points on curr_img
# (This part is for demonstration and requires a display environment)
# img_plot = img2.copy()
# for i, (xi, yi) in enumerate(new_positions_multi):
#     # Reconstruct the bounding box for plotting based on the new POI location
#     # and original template size/offset
#     x0_orig, y0_orig, w, h = init_templates_multi[i, 2:6].astype(int)
#     xi_orig, yi_orig = init_templates_multi[i, 0:2]
#     
#     # Calculate top-left of the bounding box relative to the new POI
#     box_x1 = int(xi - (xi_orig - x0_orig))
#     box_y1 = int(yi - (yi_orig - y0_orig))
#     
#     cv2.rectangle(img_plot, (box_x1, box_y1), (box_x1 + w, box_y1 + h), (0, 255, 0), 2)
#
# cv2.imshow('Tracked Points Visualization', img_plot)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
'''

"""

import numpy as np
import cv2

def template_match_subpixels(init_img, curr_img, init_templates,
                   curr_templates=None, search_range_factors=1.0):
    # Ensure init_templates is a NumPy array of float32
    init_templates = np.array(init_templates, dtype=np.float32)
    np_templates = init_templates.shape[0] # Number of templates to track

    # If no initial guess for current template positions is provided,
    # assume they are the same as the initial POI locations.
    if curr_templates is None:
        curr_templates = init_templates[:, 0:2].copy()
    
    # Initialize an array to store matching coefficients for each template
    coeffs = np.zeros(np_templates)

    # Handle search_range_factors:
    # If a single scalar is given, apply it to all templates.
    # Otherwise, ensure it's a flat array matching the number of templates.
    if np.isscalar(search_range_factors):
        search_range_factors = np.full(np_templates, float(search_range_factors))
    else:
        search_range_factors = np.array(search_range_factors).flatten()

    # Create a copy of curr_templates to store the updated (tracked) positions
    updated_templates = curr_templates.copy()

    # Iterate through each template to perform sub-pixel precision template matching
    for i in range(np_templates):
        # Extract template details from init_templates
        # xi, yi: sub-pixel POI in initial image
        # x0, y0, w, h: integer bounding box of the template in initial image
        xi, yi, x0, y0, w, h = init_templates[i]
        x0, y0, w, h = map(int, [x0, y0, w, h]) # Ensure bounding box coordinates are integers

        # Extract the template (the pattern to be matched) from the initial image
        template = init_img[y0:y0+h, x0:x0+w].copy()

        # Get the current guessed location of the POI in the current image
        gx, gy = curr_templates[i][0:2]

        # Calculate the offset of the POI relative to the template's top-left corner
        # This offset is crucial for translating the matched template position to the POI position
        dx = xi - x0
        dy = yi - y0

        # Get the dimensions of the current image
        img_h, img_w = curr_img.shape[:2]

        # Calculate the base search range dimensions.
        # This is based on the initial displacement guess and template size.
        search_range_base_x = 2 * abs(gx - xi) + w
        search_range_base_y = 2 * abs(gy - yi) + h
        
        # Apply the search_range_factor to determine the actual search area size
        search_range_x = int(search_range_base_x * search_range_factors[i])
        search_range_y = int(search_range_base_y * search_range_factors[i])

        # Define the coordinates for the search region in the current image.
        # Ensure the region stays within image boundaries (max/min with 0/img_dim).
        x1 = int(max(gx - search_range_x - dx, 0))
        y1 = int(max(gy - search_range_y - dy, 0))
        x2 = int(min(x1 + 2 * search_range_x + w, img_w))
        y2 = int(min(y1 + 2 * search_range_y + h, img_h))

        # Extract the search region from the current image
        search_region = curr_img[y1:y2, x1:x2].copy()

        # Check if the extracted search region is valid (large enough to contain the template)
        if search_region.shape[0] < h or search_region.shape[1] < w:
            # If not valid, set coefficient to 0 and skip to the next template
            coeffs[i] = 0
            continue

        # Perform standard template matching using OpenCV's TM_CCOEFF_NORMED method
        # This gives an initial integer-pixel best match location
        res = cv2.matchTemplate(search_region, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res) # max_loc is (x_peak, y_peak) in 'res'

        # Initialize sub-pixel refinements and coefficients
        x_peak, y_peak = max_loc[0], max_loc[1]
        dx_sub = 0.0
        dy_sub = 0.0
        coeff_x = max_val # Initial correlation value at the integer peak
        coeff_y = max_val # Initial correlation value at the integer peak

        # Define a kernel for parabolic fitting. This kernel helps determine the coefficients
        # of the parabola based on three points (peak and its neighbors).
        kernel = np.array([[0.5, -1, 0.5], [-0.5, 0, 0.5], [0, 1, 0]]) # Note: This kernel might be simplified for 1D parabolic fit.
                                                                    # A standard 1D parabolic fit for 3 points (x-1, x, x+1)
                                                                    # uses coefficients derived directly from the values.

        # Perform sub-pixel refinement in the X direction using parabolic interpolation
        # Only perform if the peak is not at the border of the correlation map
        if 0 < x_peak < res.shape[1]-1:
            # Get the correlation values at (x_peak-1, x_peak, x_peak+1) along the y_peak row
            vec_x = np.array([res[y_peak, x_peak - 1], res[y_peak, x_peak], res[y_peak, x_peak + 1]]).reshape(3,1)
            
            # This 'kernel' application is a bit unusual for standard parabolic interpolation
            # For 1D parabolic interpolation given 3 points (x-1, y1), (x, y2), (x+1, y3):
            # The sub-pixel offset dx_sub = (y1 - y3) / (2 * (y1 - 2*y2 + y3))
            # And the peak value is y2 - 0.25 * (y1 - y3)^2 / (y1 - 2*y2 + y3)
            # Let's use the standard formula for clarity and correctness.
            
            y_left, y_center, y_right = vec_x.flatten()
            denominator = y_left - 2 * y_center + y_right
            if denominator != 0: # Avoid division by zero
                dx_sub = (y_left - y_right) / (2 * denominator)
                # The refined peak value (coefficient)
                coeff_x = y_center - 0.25 * (y_left - y_right)**2 / denominator
            else: # If denominator is zero, it's a flat peak or linear, no parabolic refinement
                dx_sub = 0.0
                coeff_x = y_center # Use the integer peak value

        # Perform sub-pixel refinement in the Y direction using parabolic interpolation
        # Only perform if the peak is not at the border of the correlation map
        if 0 < y_peak < res.shape[0]-1:
            # Get the correlation values at (y_peak-1, y_peak, y_peak+1) along the x_peak column
            vec_y = np.array([res[y_peak - 1, x_peak],res[y_peak, x_peak],res[y_peak + 1, x_peak]]).reshape(3,1)
            
            y_up, y_center, y_down = vec_y.flatten()
            denominator = y_up - 2 * y_center + y_down
            if denominator != 0: # Avoid division by zero
                dy_sub = (y_up - y_down) / (2 * denominator)
                # The refined peak value (coefficient)
                coeff_y = y_center - 0.25 * (y_up - y_down)**2 / denominator
            else: # If denominator is zero, it's a flat peak or linear, no parabolic refinement
                dy_sub = 0.0
                coeff_y = y_center # Use the integer peak value

        # The overall matching coefficient is typically the product or geometric mean of the
        # refined coefficients in x and y. Using sqrt(coeff_x * coeff_y) is a common approach.
        coeffs[i] = float(np.sqrt(max(0, coeff_x * coeff_y))) # Ensure non-negative under sqrt

        # Calculate the final updated POI location in the current image.
        # This involves summing four components:
        # 1. x1, y1: The top-left corner of the search region (relative to curr_img's origin).
        # 2. x_peak, y_peak: The integer-pixel peak location within the 'search_region'.
        # 3. dx_sub, dy_sub: The sub-pixel offset from the integer peak.
        # 4. dx, dy: The original offset of the POI from its template's top-left corner.
        updated_templates[i] = [x1 + x_peak + dx_sub + dx, y1 + y_peak + dy_sub + dy]

    # Return the updated POI locations (np x 2 array) and their corresponding matching coefficients
    return updated_templates.reshape(-1,2), coeffs.reshape(-1)


def unit_test_01():
    import tkinter as tk
    from tkinter import filedialog, simpledialog

    root = tk.Tk()
    root.withdraw()

    # img 1 is a 300 by 300 image, white backgrounded, 
    # with 2 black squares from (140, 140) to (150, 150) and from (150, 150) to (160, 160)
    img1 = np.ones((300, 300), dtype=np.uint8) * 255
    cv2.rectangle(img1, (140, 140), (150, 150), (0, 0, 0), -1)
    cv2.rectangle(img1, (150, 150), (160, 160), (0, 0, 0), -1)
    # img 2 is a 300 by 300 image, white backgrounded, 
    # with 2 black squares from (141, 142) to (151, 152) and from (151, 152) to (161, 162)
    img2 = np.ones((300, 300), dtype=np.uint8) * 255
    cv2.rectangle(img2, (141, 142), (151, 152), (0, 0, 0), -1)
    cv2.rectangle(img2, (151, 152), (161, 162), (0, 0, 0), -1)
    # Display the images
    cv2.imshow('Initial image (image 1)', img1); ikey= cv2.waitKey(0)
    cv2.imshow('Current image (image 2)', img2); ikey= cv2.waitKey(0)
    # destroy the windows
    cv2.destroyAllWindows()

    tmplt_input1 = "150.0 150.0 135 135 30 30"  # xi, yi, x0, y0, w, h
    tmplt_input2 = "160.0 160.0 150 150 20 20"  # xi, yi, x0, y0, w, h

    if tmplt_input1 is not None and tmplt_input2 is not None:
        # combine tmplt_input1 and tmplt_input2 to init_templates, which is a 2 by 6 array
        tmplt1_values = list(map(float, tmplt_input1.split()))
        tmplt2_values = list(map(float, tmplt_input2.split()))
        init_templates = np.array([tmplt1_values, tmplt2_values], dtype=np.float32).reshape(2, 6)

    (new_position, coeffs) = template_match_subpixels(img1, img2, init_templates)
    curr_templates = new_position

    print(f"Tracked point: {new_position[:,0:2]}")
    print(f"Matching coefficient: {coeffs}")

    # Optional visualization of the results by plotting two boxes on the current image
    img_plot = img2.copy()
    for i, (xi, yi) in enumerate(new_position):
        x0, y0, w, h = init_templates[i, 2:6].astype(int)
        x1 = int(xi - (init_templates[i,0]-x0))
        y1 = int(yi - (init_templates[i,1]-y0))
        cv2.rectangle(img_plot, (int(x1), int(y1)), (int(x1 + w), int(y1 + h)), (0, 255, 0), 2)

    # 
    cv2.imshow('Tracked Points', img_plot)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def unit_test_02():
    import tkinter as tk
    from tkinter import filedialog, simpledialog
    from imshow3 import imshow3 

    root = tk.Tk()
    root.withdraw()

    # use tk file dialog to select two images
    file1 = filedialog.askopenfilename(title="Select Initial Image", filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.bmp")])
    file2 = filedialog.askopenfilename(title="Select Current Image", filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.bmp")])
    img1 = cv2.imread(file1, cv2.IMREAD_COLOR_BGR)
    img2 = cv2.imread(file2, cv2.IMREAD_COLOR_BGR)

    # use imshow3 to ask user to select templates from img1
    from imshow3 import imshow3
    Xi, Xir, names = imshow3("Initial Image (image 1)", img1)
    
    # hstack Xi and Xir into init_templates
    init_templates = np.hstack((Xi, Xir)).astype(np.float32)

    # call template_match_subpixels
    curr_templates = init_templates[:, 0:2].copy()  # initial guess is the same as the initial templates
    (new_position, coeffs) = template_match_subpixels(img1, img2, init_templates, curr_templates)

    print(f"Initial points: \n{init_templates[:,0:6]}\n")
    print(f"Tracked points: \n{new_position[:,0:2]}\n")
    print(f"Matching coefficients: {coeffs}\n")

    # Save the initial templates (init_templates) to the worksheet "initial templates" of an xlsx file
    # with these columns: poi_name, xi, yi, x0, y0, w, h 
    import openpyxl
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "initial templates"
    ws.append(["poi_name", "xi", "yi", "x0", "y0", "w", "h"])
    for i in range(init_templates.shape[0]):
        ws.append([names[i], *init_templates[i, :]])
    # Save the tracked points (new_position) to the worksheet "tracked points" of the same xlsx file
    # with these columns: poi_name, xi, yi
    ws = wb.create_sheet(title="tracked points")
    ws.append(["poi_name", "xi", "yi", "coefficient"])
    for i in range(new_position.shape[0]):
        ws.append([names[i], *new_position[i, :2], coeffs[i]])
    # Save the workbook to a file
    # use tk file dialog to select the save location
    save_file = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
    if save_file:
        wb.save(save_file)
        print(f"Results saved to {save_file}")

if __name__ == "__main__":
    # To run unit_test_01, uncomment the line below and comment out unit_test_02()
    # unit_test_01()
    # To run unit_test_02, uncomment the line below and ensure you have 'imshow3' available
    unit_test_02()