import cv2
import os

def video_2_pictures(inputs: dict) -> dict:
    """
    Convert frames of a video into image files, with optional cropping and resizing.
    
    Inputs (dictionary):
        'video_path'   : str
            Full path to the input video file.
        
        'frame_range'  : tuple (start_idx, end_idx)
            Range of frame indices to extract, inclusive of both start and end.
            For example, (100, 300) means extract frames 100 to 300.
        
        'crop_region'  : tuple (x, y, w, h)
            Region to crop from each frame. 
            (x, y) is top-left corner in pixels. w and h are width and height of cropped region.
        
        'output_size'  : tuple (width, height)
            Resize every cropped image to this size before saving. 
            If None, no resizing is done.
        
        'filenames'    : list [format_string, start_index]
            A C-style format string and starting index.
            For example, ['c:/temp/image_%05d.jpg', 10] will generate:
                'c:/temp/image_00010.jpg', 'c:/temp/image_00011.jpg', ...
    
    Output (dictionary):
        'saved_files'  : list[str]
            A list of file paths of saved images.
        'frame_indices': list[int]
            A list of video frame indices that were successfully saved.

    Example:
        inputs = {
            'video_path': 'c:/videos/sample.mp4',
            'frame_range': (100, 110),
            'crop_region': (100, 200, 640, 480),
            'output_size': (320, 240),
            'filenames': ['c:/temp/frame_%04d.png', 0]
        }
        outputs = video_2_pictures(inputs)
        print(outputs['saved_files'])
    """
    video_path = inputs['video_path']
    frame_range = inputs['frame_range']
    crop_region = inputs['crop_region']
    output_size = inputs['output_size']
    filename_format, filename_start = inputs['filenames']

    x, y, w, h = crop_region
    start_frame, end_frame = frame_range

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise IOError(f"Cannot open video: {video_path}")
    
    saved_files = []
    saved_indices = []

    for frame_idx in range(start_frame, end_frame + 1):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        success, frame = cap.read()
        if not success:
            print(f"Warning: Cannot read frame {frame_idx}")
            continue

        # Crop the frame
        cropped = frame[y:y+h, x:x+w]

        # Resize if needed
        if output_size is not None:
            cropped = cv2.resize(cropped, output_size, interpolation=cv2.INTER_AREA)

        # Generate file name
        file_index = filename_start + len(saved_files)
        filename = filename_format % file_index

        # Create directory if not exists
        os.makedirs(os.path.dirname(filename), exist_ok=True)

        # Save image
        success = cv2.imwrite(filename, cropped)
        if success:
            saved_files.append(filename)
            saved_indices.append(frame_idx)
        else:
            print(f"Warning: Failed to save {filename}")

    cap.release()

    return {
        'saved_files': saved_files,
        'frame_indices': saved_indices
    }
