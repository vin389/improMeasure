"""
Video to Pictures Tool
=======================

This Python module provides a GUI and backend function to convert a segment of a video
into multiple cropped and resized image files.

It is designed using a **dictionary-based argument style**, meaning all parameters are
passed as a dictionary (`dict`) and all results are returned as a dictionary. This makes
it highly extensible, scriptable, and suitable for GUI, CLI, or pipeline integration.

Main Function:
--------------
    video_2_pictures(inputs: dict) -> dict

Input Keys:
-----------
- 'video_path': str
    Path to the input video file.
- 'frame_range': tuple (start_frame, end_frame)
    Range of frame indices to convert (inclusive).
- 'crop_region': tuple (x, y, w, h)
    Top-left pixel position and dimensions of the region to crop from each frame.
- 'output_size': tuple (width, height) or None
    Final size to resize each cropped frame. Set to None to skip resizing.
- 'filenames': list [format_string, start_index]
    Format for saving files. For example, ['output/img_%05d.jpg', 0] will produce
    output/img_00000.jpg, output/img_00001.jpg, etc.

Output Keys:
------------
- 'saved_files': list of str
    Paths of the saved image files.
- 'frame_indices': list of int
    Frame indices that were successfully saved.

Examples:
---------
1. Convert full video:
    video_2_pictures({
        'video_path': 'video.mp4',
        'frame_range': (0, 200),
        'crop_region': (0, 0, 1920, 1080),
        'output_size': (640, 360),
        'filenames': ['output/img_%05d.jpg', 0]
    })

2. Convert and crop center 640x480 area:
    video_2_pictures({
        'video_path': 'input.avi',
        'frame_range': (10, 50),
        'crop_region': (640, 360, 640, 480),
        'output_size': (320, 240),
        'filenames': ['crop/crop_%03d.png', 1]
    })

3. No resize:
    video_2_pictures({
        'video_path': 'clip.mp4',
        'frame_range': (100, 110),
        'crop_region': (0, 0, 800, 600),
        'output_size': None,
        'filenames': ['frames/f_%02d.jpg', 0]
    })

4. Output starts at index 10:
    video_2_pictures({
        'video_path': 'vid.mov',
        'frame_range': (0, 3),
        'crop_region': (50, 50, 400, 300),
        'output_size': (400, 300),
        'filenames': ['images/pic_%02d.jpg', 10]
    })

5. Save as PNG:
    video_2_pictures({
        'video_path': 'movie.mp4',
        'frame_range': (5, 8),
        'crop_region': (100, 100, 640, 480),
        'output_size': (320, 240),
        'filenames': ['pngs/image_%04d.png', 0]
    })

6. Full HD crop to thumbnail:
    video_2_pictures({
        'video_path': 'fullhd.mp4',
        'frame_range': (200, 210),
        'crop_region': (0, 0, 1920, 1080),
        'output_size': (160, 90),
        'filenames': ['thumbs/thumb_%04d.jpg', 0]
    })

7. Extract middle portion of frames:
    video_2_pictures({
        'video_path': 'scene.mp4',
        'frame_range': (50, 55),
        'crop_region': (500, 300, 800, 600),
        'output_size': (400, 300),
        'filenames': ['middle/mid_%04d.jpg', 0]
    })

8. Use in pipeline:
    inputs = {
        'video_path': 'stream.mp4',
        'frame_range': (10, 20),
        'crop_region': (100, 100, 400, 300),
        'output_size': (200, 150),
        'filenames': ['batch/out_%04d.jpg', 0]
    }
    outputs = video_2_pictures(inputs)
    print(outputs['saved_files'])

"""

import cv2
import os
import tkinter as tk
from tkinter import filedialog, messagebox

def video_2_pictures(inputs: dict) -> dict:
    video_path = inputs['video_path']
    frame_range = inputs['frame_range']
    crop_region = inputs['crop_region']
    output_size = inputs['output_size']
    filename_format, filename_start = inputs['filenames']

    x, y, w, h = crop_region
    start_frame, end_frame = frame_range

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise IOError(f"Cannot open video: {video_path}")

    saved_files = []
    saved_indices = []

    for frame_idx in range(start_frame, end_frame + 1):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        success, frame = cap.read()
        if not success:
            print(f"Warning: Cannot read frame {frame_idx}")
            continue

        cropped = frame[y:y+h, x:x+w]
        if output_size is not None:
            cropped = cv2.resize(cropped, output_size, interpolation=cv2.INTER_AREA)

        file_index = filename_start + len(saved_files)
        filename = filename_format % file_index
        os.makedirs(os.path.dirname(filename), exist_ok=True)

        success = cv2.imwrite(filename, cropped)
        if success:
            saved_files.append(filename)
            saved_indices.append(frame_idx)
        else:
            print(f"Warning: Failed to save {filename}")

    cap.release()

    return {
        'saved_files': saved_files,
        'frame_indices': saved_indices
    }

class VideoToPicturesGUI:
    def __init__(self, master):
        self.master = master
        master.title("Video to Pictures")

        self.inputs = {
            'video_path': tk.StringVar(),
            'frame_start': tk.IntVar(value=0),
            'frame_end': tk.IntVar(value=100),
            'crop_x': tk.IntVar(value=0),
            'crop_y': tk.IntVar(value=0),
            'crop_w': tk.IntVar(value=640),
            'crop_h': tk.IntVar(value=480),
            'resize_w': tk.IntVar(value=320),
            'resize_h': tk.IntVar(value=240),
            'filename_format': tk.StringVar(value="output/image_%05d.jpg"),
            'filename_start': tk.IntVar(value=0)
        }

        self.create_widgets()

    def create_widgets(self):
        row = 0
        def entry(label, var, width=10):
            nonlocal row
            tk.Label(self.master, text=label).grid(row=row, column=0, sticky='e')       
            tk.Entry(self.master, textvariable=var, width=width).grid(row=row, column=1, sticky='w')
            row += 1

        tk.Label(self.master, text="Video Path:").grid(row=row, column=0, sticky='e')
        tk.Entry(self.master, textvariable=self.inputs['video_path'], width=50).grid(row=row, column=1, sticky='w')
        tk.Button(self.master, text="Browse", command=self.browse_video).grid(row=row, column=2)
        row += 1

        entry("Frame Start:", self.inputs['frame_start'])
        entry("Frame End:", self.inputs['frame_end'])
        entry("Crop X:", self.inputs['crop_x'])
        entry("Crop Y:", self.inputs['crop_y'])
        entry("Crop W:", self.inputs['crop_w'])
        entry("Crop H:", self.inputs['crop_h'])
        entry("Resize W:", self.inputs['resize_w'])
        entry("Resize H:", self.inputs['resize_h'])
        entry("Filename Format:", self.inputs['filename_format'], width=40)
        entry("Filename Start:", self.inputs['filename_start'])

        tk.Button(self.master, text="Run", command=self.run).grid(row=row, column=1)

    def browse_video(self):
        filename = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        if filename:
            self.inputs['video_path'].set(filename)
            # Replace input entry text with information from the video file
            cap = cv2.VideoCapture(filename)
            if cap.isOpened():
                num_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                self.inputs['frame_start'].set(0)
                self.inputs['frame_end'].set(num_frames - 1)
                self.inputs['crop_x'].set(0)
                self.inputs['crop_y'].set(0)
                self.inputs['crop_w'].set(width)
                self.inputs['crop_h'].set(height)
                self.inputs['resize_w'].set(width)
                self.inputs['resize_h'].set(height)
                self.inputs['filename_format'].set(os.path.join(os.path.dirname(filename), "frame_%05d.jpg"))
                cap.release()

    def run(self):
        input_data = {
            'video_path': self.inputs['video_path'].get(),
            'frame_range': (self.inputs['frame_start'].get(), self.inputs['frame_end'].get()),
            'crop_region': (
                self.inputs['crop_x'].get(),
                self.inputs['crop_y'].get(),
                self.inputs['crop_w'].get(),
                self.inputs['crop_h'].get()
            ),
            'output_size': (
                self.inputs['resize_w'].get(),
                self.inputs['resize_h'].get()
            ),
            'filenames': [
                self.inputs['filename_format'].get(),
                self.inputs['filename_start'].get()
            ]
        }

        try:
            output = video_2_pictures(input_data)
            messagebox.showinfo("Done", f"Saved {len(output['saved_files'])} images.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = VideoToPicturesGUI(root)
    root.mainloop()
