# Modified version of inputdlg3.py to support 'array dim0 dim1' input

import tkinter as tk
from tkinter import filedialog
import os
import numpy as np

class InputDialog3:
    active_tooltip = None

    def __init__(self, prompts, datatypes, tooltips=None, title="Input Dialog"):
        self.prompts = prompts
        self.datatypes = datatypes
        self.tooltips = tooltips if tooltips else ["" for _ in prompts]
        self.title = title
        self.entries = []
        self.values = []

    def parse_datatype(self, dtype):
        parts = dtype.strip().split()
        kind = parts[0].lower()
        args = parts[1:]
        return kind, args

    def validate_input(self, entry, kind, args):
        val = entry.get()
        try:
            if kind == 'int':
                v = int(val)
                entry.config(fg='blue' if int(args[0]) <= v <= int(args[1]) else 'red')
            elif kind == 'float':
                v = float(val)
                entry.config(fg='blue' if float(args[0]) <= v <= float(args[1]) else 'red')
            elif kind == 'file':
                entry.config(fg='blue' if os.path.isfile(val) else 'red')
            elif kind == 'dir':
                entry.config(fg='blue' if os.path.isdir(val) else 'red')
            elif kind == 'array':
                import re
#                nums = list(map(float, val.strip().split()))
                str_list = re.split(r'[\s,]+', val.strip())
                dim0, dim1 = int(args[0]), int(args[1])
#                np.array(nums).reshape((dim0, dim1))
                np.array(str_list, dtype=float).reshape((dim0, dim1))
                entry.config(fg='blue')
        except:
            entry.config(fg='red')

    def browse(self, entry, kind):
        if kind == 'file':
            path = filedialog.askopenfilename()
        elif kind == 'dir':
            path = filedialog.askdirectory()
        elif kind == 'files':
            paths = filedialog.askopenfilenames()
            entry.delete("1.0", tk.END)
            entry.insert(tk.END, "\n".join(paths))
            return
        else:
            return

        if path:
            entry.delete(0, tk.END)
            entry.insert(0, path)
            entry.event_generate('<KeyRelease>')

    def add_tooltip(self, widget, text):
        tooltip = tk.Toplevel(widget)
        tooltip.withdraw()
        tooltip.overrideredirect(True)
        label = tk.Label(tooltip, text=text, background="#ffffe0", relief='solid', borderwidth=1)
        label.pack()

        def show_tooltip(event):
            if InputDialog3.active_tooltip and InputDialog3.active_tooltip != tooltip:
                InputDialog3.active_tooltip.withdraw()
            x = event.x_root + 20
            y = event.y_root + 10
            tooltip.geometry(f"+{x}+{y}")
            tooltip.deiconify()
            InputDialog3.active_tooltip = tooltip

        def enter(event):
            if hasattr(self, "tooltip_after_id") and self.tooltip_after_id:
                widget.after_cancel(self.tooltip_after_id)
            self.tooltip_after_id = widget.after(1000, lambda: show_tooltip(event))

        def leave(event):
            if hasattr(self, "tooltip_after_id") and self.tooltip_after_id:
                widget.after_cancel(self.tooltip_after_id)
                self.tooltip_after_id = None
            tooltip.withdraw()
            if InputDialog3.active_tooltip == tooltip:
                InputDialog3.active_tooltip = None

        widget.bind("<Enter>", enter)
        widget.bind("<Leave>", leave)

    def show(self):
        self.result = None

        if tk._default_root:
            self.root = tk.Toplevel()
            self.root.transient(tk._default_root)
        else:
            hidden_root = tk.Tk()
            hidden_root.withdraw()
            self.root = tk.Toplevel(hidden_root)

        self.root.title(self.title)
        self.root.resizable(False, False)
        self.root.grab_set()

        frame = tk.Frame(self.root, padx=10, pady=10)
        frame.pack()

        for i, (prompt, dtype, tooltip) in enumerate(zip(self.prompts, self.datatypes, self.tooltips)):
            label = tk.Label(frame, text=prompt)
            label.grid(row=i, column=0, sticky='w', padx=5, pady=2)
            if tooltip:
                self.add_tooltip(label, tooltip)

            kind, args = self.parse_datatype(dtype)

            if kind == 'listbox':
                lb = tk.Listbox(frame, height=min(5, len(args)), exportselection=False)
                for item in args:
                    lb.insert(tk.END, item)
                lb.grid(row=i, column=1, sticky='w', padx=5, pady=2)
                self.entries.append(lb)
            elif kind in ['strings', 'files']:
                text = tk.Text(frame, height=3, width=40)
                text.grid(row=i, column=1, sticky='w', padx=5, pady=2)
                self.entries.append(text)
                if kind == 'files':
                    browse_button = tk.Button(frame, text="Browse...", command=lambda e=text: self.browse(e, kind))
                    browse_button.grid(row=i, column=2, sticky='w', padx=5)
            else:
                entry = tk.Entry(frame, width=40)
                entry.grid(row=i, column=1, sticky='w', padx=5, pady=2)
                self.entries.append(entry)
                if kind in ['int', 'float', 'file', 'dir', 'array']:
                    entry.bind('<KeyRelease>', lambda e, ent=entry, k=kind, a=args: self.validate_input(ent, k, a))
                if kind in ['file', 'dir']:
                    browse_button = tk.Button(frame, text="Browse...", command=lambda e=entry, k=kind: self.browse(e, k))
                    browse_button.grid(row=i, column=2, padx=5)

        button_frame = tk.Frame(frame)
        button_frame.grid(row=len(self.prompts), column=0, columnspan=3, sticky='w', pady=10)
        tk.Button(button_frame, text="OK", width=10, command=self.on_ok).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Cancel", width=10, command=self.root.destroy).pack(side=tk.LEFT, padx=5)

        self.root.wait_window()
        return self.result

    def on_ok(self):
        results = []
        for entry, dtype in zip(self.entries, self.datatypes):
            kind, args = self.parse_datatype(dtype)
            if kind == 'listbox':
                sel = entry.curselection()
                results.append(entry.get(sel[0]) if sel else '')
            elif kind in ['strings', 'files']:
                raw = entry.get("1.0", tk.END).strip()
                results.append(raw.splitlines())
            elif kind == 'array':
                raw = entry.get()
                nums = list(map(float, raw.strip().split()))
                arr = np.array(nums).reshape((int(args[0]), int(args[1])))
                results.append(arr)
            else:
                results.append(entry.get())
        self.result = results
        self.root.destroy()

def inputdlg3(prompts, datatypes, tooltips=None, title="Input Dialog"):
    dlg = InputDialog3(prompts, datatypes, tooltips, title)
    return dlg.show()

if __name__ == '__main__':
    prompts = ['Enter age:', 'Enter matrix (3x4):']
    datatypes = ['int 0 99', 'array 3 4']
    tooltips = ['Age between 0 and 99', '12 numbers separated by spaces']
    result = inputdlg3(prompts, datatypes, tooltips, title="Demo with array input")
    print("Result:", result)
